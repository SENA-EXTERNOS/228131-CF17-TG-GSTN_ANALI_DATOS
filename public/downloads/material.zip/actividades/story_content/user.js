function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6V4pjAxSl7S":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

